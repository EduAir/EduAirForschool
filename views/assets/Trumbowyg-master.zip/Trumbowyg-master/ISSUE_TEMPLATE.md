Before report an issue, be sure to put these informations. Thanks :)

### Informations

**Browser + version**:
**OS**:
**Resolution**:


### How to reproduce the bug?

